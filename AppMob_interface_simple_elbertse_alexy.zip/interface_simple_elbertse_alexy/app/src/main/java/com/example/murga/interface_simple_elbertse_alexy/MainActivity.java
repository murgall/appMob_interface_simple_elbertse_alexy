package com.example.murga.interface_simple_elbertse_alexy;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {

    private TextView Nom;
    private TextView Prenom;
    private TextView Mail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Thread t = new Thread(){
            @Override
            public void run() {
                try {
                    while (!isInterrupted() ) {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                TextView tdate = (TextView) findViewById(R.id.affich_date);
                                long date = System.currentTimeMillis();
                                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd yyyy");
                                String dateString = sdf.format(date);
                                tdate.setText(dateString);

                            }
                        });
                    }
                }catch (InterruptedException e) {

                }
            }

        };
        t.start();

        Nom=(TextView) findViewById(R.id.affich_nom);
        Prenom=(TextView) findViewById(R.id.affich_prenom);
        Mail=(TextView) findViewById(R.id.affich_mail);



        Mail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (Nom.getText() != "") {
                    if (Prenom.getText() != "") {
                        Mail.setText(Prenom.getEditableText().toString().toLowerCase().charAt(0)+Nom.getEditableText().toString().toLowerCase()+"@gmail.com");
                    }
                }
            }
        });




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }



    public void displayToastF(View v){
        Toast.makeText(MainActivity.this,"Bienvenue Madame ",Toast.LENGTH_SHORT).show();
    }

    public void displayToastH(View v){
        Toast.makeText(MainActivity.this,"Bienvenue Monsieur ",Toast.LENGTH_SHORT).show();
    }

    public void reset_field(View v) {
        Nom.setText("");
        Prenom.setText("");}



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
